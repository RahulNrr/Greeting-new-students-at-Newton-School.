import React from "react";
import Welcome from "./components/Welcome";

const App = () => {
  return <Welcome name="" />;
};

export default App;
